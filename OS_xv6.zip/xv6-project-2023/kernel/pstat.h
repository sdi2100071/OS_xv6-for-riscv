// #include "kernel/types.h"
#define NPROC        64  // maximum number of processes

enum procstate { UNUSED, USED, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

struct pstat{
                 
  int pid[NPROC];                     // Process ID
  int priority[NPROC];                // Priority value
  char name[NPROC][16];               // Process name 
  enum procstate state[NPROC];        // Process state
  uint64 sz[NPROC];                   // Size of process memory (bytes)

  struct proc *parent[NPROC];         // Parent process

  int ppid[NPROC];



};
