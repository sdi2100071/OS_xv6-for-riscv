#include "user/user.h"
#include "kernel/types.h"
#include "kernel/stat.h"

int main(){

    // printf("Hello World");
    hello();

    setpriority(5);
    
    exit(0);
}