#include "user/user.h"
#include "kernel/types.h"
#include "kernel/stat.h"

int main(){

    struct pstat procstat;
    
    //  call getpinfo
    getpinfo(&procstat);

    const char* stateNames[] = {"UNUSED", "USED", "SLEEPING", "RUNNABLE", "RUNNING", "ZOMBIE" };
    
    //  print pstat for every not unused proccess
    for(int i = 0; i <= NPROC - 1; i++){
        
        if(procstat.state[i] == UNUSED)
            continue;
    
        printf("PID : %d               ",procstat.pid[i]);
        printf("PRIORITY : %d          ",procstat.priority[i]);
        printf("NAME : %s              ",procstat.name[i]);
        printf("SIZE : %d              ",procstat.sz[i]);
        printf("STATE: %s              ",stateNames[procstat.state[i]]);
        printf("PARENT ID: %d          ",procstat.ppid[i]);

        printf("%c",10);
    }
    exit(0);
}